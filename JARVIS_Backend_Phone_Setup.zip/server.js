import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "16kb" }));

app.get("/health", (_req, res) => res.json({ ok: true }));

const limiter = rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.RATE_LIMIT_PER_MINUTE || 20),
  standardHeaders: "draft-7",
  legacyHeaders: false
});

async function openAI(message, language) {
  if (!process.env.OPENAI_API_KEY) throw new Error("OpenAI key missing");
  const r = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.4-mini",
      instructions: `You are JARVIS, a helpful Android voice assistant. Reply in ${language}. Be concise. Do not claim to control the phone.`,
      input: message,
      max_output_tokens: 500,
      store: false
    }),
    signal: AbortSignal.timeout(25000)
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`OpenAI HTTP ${r.status}`);
  const text = data.output_text || (data.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n");
  if (!text) throw new Error("Empty OpenAI response");
  return text.trim();
}

async function gemini(message, language) {
  if (!process.env.GEMINI_API_KEY) throw new Error("Gemini key missing");
  const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "x-goog-api-key": process.env.GEMINI_API_KEY, "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: `You are JARVIS, a helpful Android voice assistant. Reply in ${language}. Be concise. Do not claim to control the phone.` }] },
      contents: [{ role: "user", parts: [{ text: message }] }],
      generationConfig: { maxOutputTokens: 500, temperature: 0.6 }
    }),
    signal: AbortSignal.timeout(25000)
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Gemini HTTP ${r.status}`);
  const answer = (data.candidates?.[0]?.content?.parts || []).map(x => x.text || "").join("").trim();
  if (!answer) throw new Error("Empty Gemini response");
  return answer;
}

app.post("/chat", limiter, async (req, res) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const language = req.body?.language === "en-US" ? "en-US" : "ur-PK";
  const provider = String(req.body?.provider || process.env.JARVIS_PROVIDER || "auto").toLowerCase();
  if (!message || message.length > 4000) return res.status(400).json({ error: "message must be 1–4000 characters" });
  if (!["auto", "openai", "gemini"].includes(provider)) return res.status(400).json({ error: "invalid provider" });
  try {
    let reply, used;
    if (provider === "openai") { reply = await openAI(message, language); used = "openai"; }
    else if (provider === "gemini") { reply = await gemini(message, language); used = "gemini"; }
    else {
      try { reply = await openAI(message, language); used = "openai"; }
      catch (e) {
        if (!process.env.GEMINI_API_KEY) throw e;
        reply = await gemini(message, language); used = "gemini";
      }
    }
    res.json({ reply, provider: used });
  } catch (e) {
    console.error("Provider error:", e.message);
    res.status(502).json({ error: "AI provider unavailable. Check server configuration." });
  }
});

const port = Number(process.env.PORT || 10000);
app.listen(port, "0.0.0.0", () => console.log(`JARVIS backend listening on ${port}`));
